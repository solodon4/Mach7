#pragma once

#include <iostream>
#include <string>

//==============================================================================
// Forward declarations
//==============================================================================
// Seems to be the only way to include definitions required by union in cou.tab.hpp

#include "cou.tab.hpp"
